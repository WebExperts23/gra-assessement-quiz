(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */


	 	// add row
            // $(document).on('click', '#addRow', function () {
            //     var html = '';
            //     html += '<div id="inputFormRow">';
            //     html += '<div class="form-group input-group">';
            //     html += '<input type="text" name="quiz_field_value" id="quiz_field_value" class="bbMemberFields w-50 mr-3" value=""> ';
            //     html += '<input type="text" name="quiz_answer_prefix" id="quiz_answer_prefix" class="bbMemberFields w-50 mr-3" value=""> ';
            //     html += '<div class="input-group-append">';
            //     html += '<button id="removeRow" type="button" class="btn btn-danger btn-sm">Remove</button>';
            //     html += '</div>';
            //     html += '</div>';
            //     html += '</div>';


            //     $('#newRow').append(html);
            // });

            // // remove row
            // $(document).on('click', '#removeRow', function () {
            //     $(this).closest('#inputFormRow').remove();
            // });


            // $(document).on('click', '#addInput', function () {
            //     var html = '';
            //     html += '<div class="row" id="inputFormInput">';
            //     html += '<div class="col-md-4">';
            //     html += '<div class="form-group">';
            //     html += '<input type="radio" name="quiz_bb_mebmer_fields" id="quiz_bb_mebmer_fields" class="bbMemberFields" value=""/> Personality';
            //     html += '</div>';
            //      html += '<div class="form-group">';
            //     html += '<input type="radio" name="quiz_bb_mebmer_fields" id="quiz_bb_mebmer_fields" class="bbMemberFields" value=""/> Quiz';
            //     html += '</div>';
            //     html += '</div>';

            //     html += '<div class="col-md-4">';
            //     html += '<div class="form-group input-group">';
            //     html += '<input type="text" name="quiz_form_id" id="quiz_form_id" class="bbMemberFields w-100 mr-3" value="">';
            //     html += '</div>';
            //     html += '</div>';

            //     html += '<div class="col-md-4">';
            //     html += '<div class="form-group input-group">';
            //     html += ' <input type="text" name="quiz_redirect_page_url" id="quiz_redirect_page_url" class="bbMemberFields w-100 mr-3" value="">';
            //     html += '<div class="input-group-append">';
            //     html += '<button id="removeInput" type="button" class="btn btn-danger btn-sm">Remove</button>';
            //     html += '</div>';
            //     html += '</div>';
            //     html += '</div>';
            //     html += '</div>';
            //     html += '<hr>';



            //     $('#newInput').append(html);
            // });

            // // remove row
            // $(document).on('click', '#removeInput', function () {
            //     $(this).closest('#inputFormInput').remove();
            // });



            



})( jQuery );
