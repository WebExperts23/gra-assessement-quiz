<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
    div#wpcontent {background-color: #F1F1F1;   }
    .container { max-width: 100%;}
    .card{max-width: none;}
</style>
<script>
    jQuery(document).ready(function() {

        // // Plugin Disable enable settings
        jQuery('button.quiz_bb_members_fields_settings').on('click', function(e) {
           e.preventDefault();
            var select_user = jQuery('input[name="quiz_bb_mebmer_fields"]:checked').val();
            var quiz_bb_mebmer_groups = [];
            jQuery('.quiz_bb_mebmer_groups').find('option:selected').each(function(){
                    quiz_bb_mebmer_groups.push(jQuery(this).val());
            });

            var quiz_form_id = [];
            jQuery('.quiz_form_id').find('option:selected').each(function(){
                    quiz_form_id.push(jQuery(this).val());
            });

            var quiz_field_value = [];
            jQuery('input[name="quiz_field_value"]').each(function() {
                quiz_field_value.push(jQuery(this).val());
            });

            jQuery.post(
                ajaxurl,
                {
                    "action": "save_bb_members_xprofile_fields",
                    "quiz_bb_mebmer_fields": select_user,
                    "quiz_form_id": quiz_form_id,
                    "quiz_field_value": quiz_field_value,
                    "quiz_bb_mebmer_groups" : quiz_bb_mebmer_groups,
                }
            )
                .done(function(data) {
                    jQuery('p#cut_off_message').slideUp();
                        display_message(data.success, false, 'cut_off_message');  
                        console.log(data);
                        window.location.reload();  
                })
                .fail(function(data) {
                    jQuery('p#cut_off_message').slideUp();
                    var response = data.responseText;
                    response = $.parseJSON(response);
                    window.location.reload();

                    if(response) {
                        display_message(response.error, true, 'cut_off_message');
                    } else {
                        display_message('Unexpected error occurred.', true, 'cut_off_message');
                    }
                });
        });


        jQuery('button.quiz_prefix_fields').on('click', function(e) {            
           e.preventDefault();
            var quiz_field_value = [];
            jQuery('input[name="quiz_field_value"]').each(function() {
                quiz_field_value.push(jQuery(this).val());
            });

            var quiz_answer_prefix = [];
              jQuery('input[name="quiz_answer_prefix"]').each(function() {
                quiz_answer_prefix.push(jQuery(this).val());
              });

            var profile_prefix = jQuery('input[name="profile_prefix"]').val();


            jQuery.post(
                ajaxurl,
                {
                    "action": "save_quiz_fields_ans_prefix",
                    "quiz_field_value": quiz_field_value,
                    "quiz_answer_prefix": quiz_answer_prefix,
                    "profile_prefix": profile_prefix,
                }
            )
                .done(function(data) {
                    //jQuery('p#quiz_off_message').slideUp();
                        display_message(data.success, false, 'quiz_off_message');  
                        console.log(data); 
                        window.location.reload();  
                           
                })
                .fail(function(data) {
                    jQuery('p#quiz_off_message').slideUp();
                    var response = data.responseText;
                    response = $.parseJSON(response);

                    if(response) {
                        display_message(response.error, true, 'quiz_off_message');
                    } else {
                        display_message('Unexpected error occurred.', true, 'quiz_off_message');
                    }
                });

       });

        jQuery('.quiz_bb_mebmer_groups').on('click', function(e) {

            var quiz_bb_mebmer_groups = jQuery(this).val();

            jQuery.post(
                ajaxurl,
                {
                    "action": "save_bb_members_xprofile_groups",
                    "quiz_bb_mebmer_groups": quiz_bb_mebmer_groups,
                }
            ).done(function(data) {  

                jQuery('.selected_fields').html(data);
                console.log(data); });


        });
       
               
        function display_message(message, is_error, id_name) {
            if(is_error) {
                jQuery('p#'+id_name)
                    .find('small')
                    .html('<i class="fa fa-exclamation-triangle"></i> ' + message)
                    .removeClass('text-success')
                    .addClass('text-danger');
                jQuery('p#'+id_name).slideToggle();
            } else {
                jQuery('p#'+id_name)
                    .find('small')
                    .html('<i class="fa fa-check"></i> ' + message)
                    .removeClass('text-danger')
                    .addClass('text-success');
                jQuery('p#'+id_name).slideToggle();
            }
        }


        jQuery(document).on('click', '#addInput', function () {
            var html = '';
            html += '<div id="inputFormInput">';
            html += '<div class="form-group input-group">';
            html += '<select name="quiz_form_id" id="quiz_form_id" class="quiz_form_id bbMemberFields w-100 mr-3">';
            <?php global $wpdb;
            $leaderboard_table = $wpdb->prefix . 'gf_form';
            $result = $wpdb->get_results("SELECT * FROM $leaderboard_table");
            foreach ($result as $print) { ?>
                html += '<option value="<?php echo $print->id; ?>"><?php echo $print->title; ?> </option>';
            <?php } ?>

            html += '</select>';
            html += '<div class="input-group-append">';
            html += '<button id="removeInput" type="button" class="btn btn-danger btn-sm">Remove</button>';
            html += '</div>';
            html += '</div>';
            html += '</div>';

            jQuery('#newInput').append(html);
        });

            // remove row
        jQuery(document).on('click', '#removeInput', function () {
            jQuery(this).closest('#inputFormInput').remove();
        });
   

    });

</script>

<?php 
    global $wpdb;
    $leaderboard_table = $wpdb->prefix . 'gf_form';
    $bp_xprofile_groups = $wpdb->prefix . 'bp_xprofile_groups';
    $bp_fields_table = $wpdb->prefix . 'bp_xprofile_fields';
    $gquiz_prefix = $wpdb->prefix . 'gquiz_prefix';
    $memberValue = get_option('quiz_bb_mebmer_fields', true);

?>
<div class="wrap gravity_quiz" style="background-color: #F1F1F1;">
    <h2><?= esc_html__('TribePUB Assessment Tool Configuration Dashboard', 'gravity-quiz-assessment' ); ?></h2>
    <div class="container tripub_section">
        <div class="row">
            <div class="col-md-6">
                <div class="card " >
                    <div class="card-body">

                            <?php if(count($getXprofileAdditionalFields) > 0) : ?>

                                <form method="POST">
                                    <div class="row">
                                        <div class="col-md-6">
                                          <label class="w-33"> <strong><?= esc_html__( 'Select BuddyBoss Profile Group', 'gravity-quiz-assessment' ); ?></strong> </label> 
                                          <div class="form-group">
                                            <select name="quiz_bb_mebmer_groups" id="quiz_bb_mebmer_groups" class="quiz_bb_mebmer_groups">
                                                <option value=""> -- Select BuddyBoss Profile Groups -- </option>
                                                <?php 
                                                $getXprofileAdditionalGroups = $wpdb->get_results("SELECT * FROM $bp_xprofile_groups");
                                                $selectedGroups = get_option('quiz_groups_values',true);

                                                foreach($getXprofileAdditionalGroups as $Groups){ ?>
                                                <option value="<?php echo $Groups->id; ?>" <?php echo ($Groups->id == $selectedGroups) ? 'selected' : ''  ?> > <?php echo $Groups->name; ?> </option>
                                                <?php } ?>
                                            </select>
                                          </div>

                                        <?php if($selectedGroups){ ?>
                                        <div class="selected_fields"> 
                                            <label class="w-33"> <strong><?= esc_html__( 'Select BuddyBoss Profile Field', 'gravity-quiz-assessment' ); ?></strong> </label>  
                                            <?php 
                                            $getXprofileAdditionalFields = $wpdb->get_results("SELECT * FROM ".$bp_fields_table." WHERE `parent_id` = 0 AND `group_id` = $selectedGroups");

                                            foreach($getXprofileAdditionalFields as $key => $value) :?>
                                                <div class="form-group">
                                                    <input type="radio" name="quiz_bb_mebmer_fields" id="quiz_bb_mebmer_fields" class="bbMemberFields" value="<?php echo  $value->id;  ?>"  <?php echo ($memberValue == $value->id) ? 'checked="checked"' : ''  ?>  /> <?= esc_html__($value->name, 'gravity-quiz-assessment' ); ?>
                                                </div>
                                                <?php endforeach; ?>
                                            <?php } ?>
                                        </div>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="w-33"> <strong><?= esc_html__( 'Gravity Assessment Form', 'gravity-quiz-assessment' ); ?></strong> </label>
                                                <?php  
                                                    $result = $wpdb->get_results("SELECT * FROM $leaderboard_table");
                                                    $quiz_form_id = get_option('quiz_form_id', true); 
                                                    $quiz_form_id = explode(",", $quiz_form_id);

                                                    foreach( $quiz_form_id as $quiz_id ) { 
                                                 ?>

                                                <div id="inputFormInput">
                                                    <div class="form-group input-group">
                                                        <select id="quiz_form_id" name="quiz_form_id" class=" quiz_form_id bbMemberFields w-100 mr-3">
                                                            <?php foreach ($result as $print) { ?>
                                                            <option value="<?php echo $print->id; ?>" <?php echo ($quiz_id == $print->id) ? 'selected="selected"' : ''  ?>> <?php echo $print->title; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                        <div class="input-group-append">
                                                            <button id="removeInput" type="button" class="btn btn-danger btn-sm">Remove</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php } ?>

                                                <div id="newInput"></div>
                                                <button id="addInput" type="button" class="btn btn-info btn-sm mb-4">Add Row</button>
                                        </div>

                                    </div>

                                    <p id="cut_off_message" class="success-quiz" style="display: none;"><small></small></p>
                                    <button type="submit" class="btn btn-primary btn-sm quiz_bb_members_fields_settings" style="margin-left: -15px;" ><?= esc_html__( 'Save Settings', 'gravity-quiz-assessment' ); ?></button>
                                </form>
                            <?php else : ?>

                                <p><?= esc_html__( 'There no any BB members additional fields', 'gravity-quiz-assessment' ); ?></p>

                            <?php endif; ?>


                        
                        
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card" >
                    <div class="card-body">
                        <div class="row">
                            <form method="POST" class="quiz_prefix_form">
                               <div class="col-md-12">

                                        <div class="quiz_label">
                                            <label class="w-50"> <strong><?= esc_html__( 'Enter Field Values', 'gravity-quiz-assessment' ); ?></strong> </label>
                                            <label class="w-50"> <strong><?= esc_html__( 'Answer Prefix', 'gravity-quiz-assessment' ); ?></strong> </label>
                                        </div>

                                        <?php   

                                            $quiz_fields_values = get_option('quiz_fields_values', true); 
                                            $adasdcdsc = explode(",", $quiz_fields_values);
                                            //$quiz_fields_prefix = get_option('quiz_fields_prefix', true); 
                                            //$prefixs = explode(",", $quiz_fields_prefix);
                                            $quiz_bb_mebmer_fields = get_option('quiz_bb_mebmer_fields', true); 

                                            $selected_prefix = $wpdb->get_results("SELECT prefix_value FROM $gquiz_prefix  WHERE profile_id = $quiz_bb_mebmer_fields");

                                            $prefixs = explode(",", $selected_prefix[0]->prefix_value);

                                            $bp_fields_table = $wpdb->get_results("SELECT name FROM $bp_fields_table  WHERE parent_id = $memberValue");

                                            echo '<input type="hidden" name="profile_prefix" value="'.$quiz_bb_mebmer_fields.'">';

                                        foreach( $bp_fields_table as $index => $code ) { 
                                        ?>
                                        <div id="inputFormRow">
                                            <div class="form-group input-group">
                                               
                                                <input type="text" name="quiz_field_value" id="quiz_field_value" class="quiz_field_value bbMemberFields w-50 mr-3" value="<?php echo $code->name; ?>" disabled> 
                                                <input type="text" name="quiz_answer_prefix" id="quiz_answer_prefix" class="bbMemberFields w-50 mr-3" value="<?php echo $prefixs[$index]; ?>"> 
                                            </div>  
                                        </div>
                                        <?php  } ?>
                               </div>

                               <div class="col-md-12">
                                   <p id="quiz_off_message" style="display: none;"><small></small></p>
                                   <button type="submit" class="btn btn-primary btn-sm quiz_prefix_fields"><?= esc_html__( 'Submit', 'gravity-quiz-assessment' ); ?></button>
                                </div>
                            </form>
                       </div>
                    </div>
                </div>
            </div>

            <?php 

            global $wpdb;
            $bp_fields_table = $wpdb->prefix . 'bp_xprofile_fields';
            $memberValue = get_option('quiz_bb_mebmer_fields', true);
            $selected_profiles = $wpdb->get_results("SELECT * FROM ".$bp_fields_table." WHERE `id` = $memberValue");
             ?>
            <div class="col-md-6">
                <div class="card" >
                    <h3><?= esc_html__('Assessment Results History Shortcode', 'gravity-quiz-assessment' ); ?></h3>
                    <div class="card-body">
                        <div class="row">
                             <table class="resposive-table">
                                 <thead>
                                     <th>BuddyBoss Profile Field Name</th>
                                     <th>Shortcode</th>
                                     <th>Action</th>
                                 </thead>
                                 <tbody>
                                     <tr>
                                        <td> <?php echo $selected_profiles[0]->name; ?> </td>
                                        <td class="copy_shortcode" id="<?php echo $memberValue; ?>"> [quiz_entry_data id="<?php echo $memberValue; ?>"] </td>
                                        <td> <a href="javascript:void(0)" class="copy-shortcode" onclick="copyToClipboard(<?php echo $memberValue; ?>)"> <i class="fa fa-copy"></i> </a> </td>
                                    </tr>
                                 </tbody>
                             </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card" >
                    <h3><?= esc_html__('Assessment Results Page Shortcode', 'gravity-quiz-assessment' ); ?></h3>
                    <div class="card-body">
                        <div class="row">
                            <table class="resposive-table">
                             <thead>
                                 <th>Shortcode</th>
                                 <th>Action</th>
                             </thead>
                             <tbody>
                                 <tr><td class="copy_shortcode" id="1"> [quiz_result] </td>
                                     <td> <a href="javascript:void(0)" class="copy-shortcode" onclick="copyToClipboard(1)"> <i class="fa fa-copy"></i> </a></td> </tr>
                                 </tbody>
                             </table>
                         </div>
                     </div>
                 </div>
             </div>

        </div>



    </div>
</div>


<script type="text/javascript">

    function copyToClipboard(elementId) {
      jQuery(document).find('td.copy_shortcode').each(function(){
          jQuery(this).css('color','#000');
      })

      document.getElementById(elementId).style.color = '#979393';  

      // Create a "hidden" input
      var aux = document.createElement("input");
  
      // Assign it the value of the specified element
      aux.setAttribute("value", document.getElementById(elementId).innerHTML);

      // Append it to the body
      document.body.appendChild(aux);

      // Highlight its content
      aux.select();

      // Copy the highlighted text
      document.execCommand("copy");

      // Remove it from the body
      document.body.removeChild(aux);


    }

</script>