<?php 


function de_gforms_confirmation_dynamic_redirect( $confirmation, $form, $entry, $ajax ) {

  $quiz_form_id = get_option('quiz_form_id', true); 
  $quiz_form_idss = explode(",", $quiz_form_id);

    foreach( $quiz_form_idss as $form_idss ) {

      if ($form_idss == $form['id']) {

        global $wpdb;
        $gquiz_prefix = $wpdb->prefix . 'gquiz_prefix';

        foreach($form['confirmations'] as $url ) {
            $redirect_url = $url['url']; 
          }

       $quiz_field = array();
       foreach( $form['fields'] as $value ) {  

        if($value->type == 'radio') {

          $quiz_field[] = $_POST["input_".$value->id.""];

        }

        if($value->type == 'hidden') {
           $hidden_field = 'input_'.$value->id.'';
        }

      }

      $user_id = get_current_user_id(); 
      $Arrcount = array_count_values($quiz_field);
      $Alink = array();
      $Arrayjson = array();
      foreach( $quiz_field as $index => $code ) { 

        $finaltotal += substr($code, -2);
        $quiz_fields_values = get_option('quiz_fields_values', true); 
        $adasdcdsc = explode(",", $quiz_fields_values);
        $quiz_bb_mebmer_fields = get_option('quiz_bb_mebmer_fields', true);


        // $quiz_fields_prefix = get_option('quiz_fields_prefix', true); 
        // $prefixs = explode(",", $quiz_fields_prefix);

        $selected_prefix = $wpdb->get_results("SELECT prefix_value FROM $gquiz_prefix  WHERE profile_id = $quiz_bb_mebmer_fields");

        $prefixs = explode(",", $selected_prefix[0]->prefix_value);

        foreach( $adasdcdsc as $datas => $alldata ) {

          if(substr($code,0,2) == $prefixs[$datas]){

            $Alink[substr($code,0,2)] = $alldata;
            $Arrayjson[$alldata] += substr($code, -2);
          }

        }

      }

      $quiz_fields = get_option('quiz_fields_values', true); 
      $findarray = explode(",", $quiz_fields);
      $findArry = array();
      foreach( $findarray as $indexx => $findAr ) {
        $findArry[$findAr] = '0';
      }
      $result=array_diff_key($findArry,$Arrayjson);  
      $josn_array = array_merge($result,$Arrayjson);

      $redirect = array();
      $profiles = array();
      foreach( $josn_array as $option => $count ) {

        $redirect[] = $option.'='.$count.'';
        $profiles[$count] = $option;
      }


      $ArrTotal = array('Total='.$finaltotal);
      $Types = max(array_keys($profiles));
      $fintype = array('Profile='.$profiles[$Types].'');

      $mainArr = array_merge($redirect, $ArrTotal, $fintype);
      $lindata = implode('&', $mainArr);

      $output = array( 'field_data' => array($josn_array), 'Total' => $finaltotal, 'profile' => $profiles[$Types]);
      $quiz_data = json_encode( $output );

      global $wpdb;
      $gquiz_data = $wpdb->prefix . "gquiz_data";

      if($output) {

        $wpdb->query( $wpdb->prepare( "INSERT INTO {$gquiz_data} (entry_id, user_id, field_id, quiz_values) VALUES (%d, %d, %d, %s)", $entry['id'], $user_id, $quiz_bb_mebmer_fields, $quiz_data ) );
      }

     $memberfieldsValue = get_option('quiz_bb_mebmer_fields', true);
     $wp_bp_xprofile_data = $wpdb->prefix . "bp_xprofile_data";

     $getProfileData = $wpdb->get_results("SELECT * FROM ".$wp_bp_xprofile_data." WHERE `user_id` = ".$user_id." AND `field_id` = ".$memberfieldsValue." ");

     if(!empty( $getProfileData )){

      $wpdb->query( $wpdb->prepare( "UPDATE $wp_bp_xprofile_data SET value = %s, last_updated = %s WHERE user_id = %d AND id = %d",$profiles[$Types], date('Y-m-d H:i:s') , $user_id, $getProfileData[0]->id ) );

    }else{

      $wpdb->query( $wpdb->prepare( "INSERT INTO {$wp_bp_xprofile_data} (user_id, field_id, value, last_updated) VALUES (%d, %d, %s, %s)", $user_id, $memberfieldsValue, $profiles[$Types], date('Y-m-d H:i:s') ) );
    }


    $confirmation = array( 'redirect' => $redirect_url .'?'.preg_replace("/\s+/", "", $lindata).'' );


  }
  }

  return $confirmation;

}
add_filter( 'gform_confirmation', 'de_gforms_confirmation_dynamic_redirect', 10, 4 );

  // ============ Form ID END


add_filter("gform_pre_submission", "after_submissionsssss");
function after_submissionsssss( $form ) { 

  $quiz_form_id = get_option('quiz_form_id', true); 
  $quiz_form_idss = explode(",", $quiz_form_id);

    foreach( $quiz_form_idss as $form_idss ) {

      if ($form_idss == $form['id']) {

        global $wpdb;
        $gquiz_prefix = $wpdb->prefix . 'gquiz_prefix';

        foreach($form['confirmations'] as $url ) {
            $redirect_url = $url['url']; 
          }

       $quiz_field = array();
       foreach( $form['fields'] as $value ) {  

        if($value->type == 'radio') {

          $quiz_field[] = $_POST["input_".$value->id.""];

        }

        if($value->type == 'hidden') {
           $hidden_field = 'input_'.$value->id.'';
        }

      }

      $user_id = get_current_user_id(); 
      $Arrcount = array_count_values($quiz_field);
      $Alink = array();
      $Arrayjson = array();
      foreach( $quiz_field as $index => $code ) { 

        $finaltotal += substr($code, -2);
        $quiz_fields_values = get_option('quiz_fields_values', true); 
        $adasdcdsc = explode(",", $quiz_fields_values);
        $quiz_bb_mebmer_fields = get_option('quiz_bb_mebmer_fields', true);


        // $quiz_fields_prefix = get_option('quiz_fields_prefix', true); 
        // $prefixs = explode(",", $quiz_fields_prefix);

        $selected_prefix = $wpdb->get_results("SELECT prefix_value FROM $gquiz_prefix  WHERE profile_id = $quiz_bb_mebmer_fields");

        $prefixs = explode(",", $selected_prefix[0]->prefix_value);

        foreach( $adasdcdsc as $datas => $alldata ) {

          if(substr($code,0,2) == $prefixs[$datas]){

            $Alink[substr($code,0,2)] = $alldata;
            $Arrayjson[$alldata] += substr($code, -2);
          }

        }

      }

      $quiz_fields = get_option('quiz_fields_values', true); 
      $findarray = explode(",", $quiz_fields);
      $findArry = array();
      foreach( $findarray as $indexx => $findAr ) {
        $findArry[$findAr] = '0';
      }
      $result=array_diff_key($findArry,$Arrayjson);  
      $josn_array = array_merge($result,$Arrayjson);

      $redirect = array();
      $profiles = array();
      foreach( $josn_array as $option => $count ) {

        $redirect[] = $option.'='.$count.'';
        $profiles[$count] = $option;
      }

      $ArrTotal = array('Total='.$finaltotal);
      $Types = max(array_keys($profiles));
      $_POST[$hidden_field] = $profiles[$Types];

  }
  }

}

