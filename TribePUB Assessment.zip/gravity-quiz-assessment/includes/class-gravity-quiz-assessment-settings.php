<?php


class Gravity_Quiz_Assessment_Settings {



    public function add_gravity_quiz_fields_menu() {
         global $current_user;
         
        $user_roles = $current_user->roles;
        if($user_roles[0] == 'administrator'){

          add_menu_page('TribePUB Assessment', 'TribePUB Assessment', 'manage_options', 'tribepub-assessment-tool-settings', array($this, 'tribepub_assessment_quiz_settings'),'dashicons-clipboard', 10 );

           add_submenu_page( 'tribepub-assessment-tool-settings', 'Documentation', 'Documentation', 'read', 'tribepub-assessment-tool-documentation', array($this, 'tribepub_assessment_quiz_documentation'));

        }
        
    }


    public function tribepub_assessment_quiz_documentation() { 

        echo '<div class="wrap gravity_quiz" style="background-color: #F1F1F1;">
                <h2> Documentation </h2>
             </div>';

    }


    public function tribepub_assessment_quiz_settings() { 

        global $wpdb;
        $bp_xprofile_groups = $wpdb->prefix . 'bp_xprofile_groups';
        $bp_xprofile_fields = $wpdb->prefix . "bp_xprofile_fields";


        $getXprofileAdditionalFields = $wpdb->get_results("SELECT * FROM ".$bp_xprofile_fields." WHERE `field_order` != 0 ");

        ob_start();
        include __DIR__ . '/../admin/partials/bb_members/index.php';
        $result = ob_get_clean();
        echo $result;

    }

    public function save_bb_members_xprofile_groups(){

        global $wpdb;
        $bp_fields_table = $wpdb->prefix . 'bp_xprofile_fields';

        $quiz_bb_mebmer_groups = $_POST['quiz_bb_mebmer_groups'];

        echo '<label class="w-33"> <strong>Select BuddyBoss Profile Field</strong> </label>';

         $getXprofileAdditionalFields = $wpdb->get_results("SELECT * FROM ".$bp_fields_table." WHERE `parent_id` = 0 AND `group_id` = $quiz_bb_mebmer_groups");

        foreach($getXprofileAdditionalFields as $key => $value) {
            echo '<div class="form-group">';
            echo '<input type="radio" name="quiz_bb_mebmer_fields" id="quiz_bb_mebmer_fields" class="bbMemberFields" value="'.$value->id.'"/> '.$value->name.' ';
            echo '</div>';
        }

        wp_die();
    }


    public function save_bb_members_xprofile_fields(){
      global $wpdb;

      if( $_POST['action'] == 'save_bb_members_xprofile_fields' ){
         
         $xProfileFields = $_POST['quiz_bb_mebmer_fields'];
         $quiz_form_id = $_POST['quiz_form_id'];
         $quiz_form_ids=implode(",",$quiz_form_id); 

         $quiz_bb_mebmer_groups = $_POST['quiz_bb_mebmer_groups'];
         $quiz_bb_mebmer_groupss=implode(",",$quiz_bb_mebmer_groups);
 
         // foreach ($xProfileFields as $key => $value) {
         //    update_option( $value['title'] , $value['value']);

         // }

          $bp_fields_table = $wpdb->prefix . 'bp_xprofile_fields';
          $bp_fields_tabless = $wpdb->get_results("SELECT name FROM $bp_fields_table  WHERE parent_id = $xProfileFields");
          $quiz_field_name = array();
          foreach( $bp_fields_tabless as $code ) {
            $quiz_field_name[] = $code->name;
         }

         $quiz_field_value=implode(",",$quiz_field_name); 

         if(get_option('quiz_groups_values') || empty(get_option('quiz_groups_values')) ){
            update_option('quiz_groups_values', $quiz_bb_mebmer_groupss);
        }else{
            add_option("quiz_groups_values", $quiz_bb_mebmer_groupss);
        }

         if(get_option('quiz_fields_values') || empty(get_option('quiz_fields_values')) ){
            update_option('quiz_fields_values', $quiz_field_value);
        }else{
            add_option("quiz_fields_values", $quiz_field_value);
        }

        if(get_option('quiz_form_id') || empty(get_option('quiz_form_id')) ){

            update_option('quiz_form_id', $quiz_form_ids);
        }else{
            add_option("quiz_form_id", $quiz_form_ids);
        }
         
        if(get_option('quiz_bb_mebmer_fields') || empty(get_option('quiz_bb_mebmer_fields')) ){
            update_option('quiz_bb_mebmer_fields', $xProfileFields);
        }else{
            add_option("quiz_bb_mebmer_fields", $xProfileFields);
        }

          return wp_send_json(array('success' => 'BB Members Fields Setting Updated!'), 200);    
      }else{
          return wp_send_json(array('error' => 'Bad Request Format!'), 422);   
      }

    }


    public function save_quiz_fields_ans_prefix(){

        global $wpdb;
        $gquiz_prefix = $wpdb->prefix . 'gquiz_prefix';
            
            if( $_POST['action'] == 'save_quiz_fields_ans_prefix' ){

                $quiz_field_value = $_POST['quiz_field_value'];
                $quiz_field_valuess = implode(",",$quiz_field_value); 
                $quiz_answer_prefix = $_POST['quiz_answer_prefix'];
                $quiz_answer_prefixss = implode(",",$quiz_answer_prefix);
                $profile_prefix = $_POST['profile_prefix']; 

                if(get_option('quiz_fields_values') || empty(get_option('quiz_fields_values')) ){
                    update_option('quiz_fields_values', $quiz_field_valuess);
                }else{
                    add_option("quiz_fields_values", $quiz_field_valuess);
                }

                $selected_prefix = $wpdb->get_results("SELECT * FROM $gquiz_prefix  WHERE profile_id = $profile_prefix");

                 if(empty($selected_prefix)){

                $data = array('prefix_value' => $quiz_answer_prefixss , 'profile_id' => $profile_prefix);
                    $format = array('%s', '%d');
                    $wpdb->insert($gquiz_prefix,$data,$format);

                }else{

                   $datas = $wpdb->query("UPDATE $gquiz_prefix SET prefix_value='$quiz_answer_prefixss', profile_id='$profile_prefix' WHERE profile_id='$profile_prefix'");

                }


                // if(get_option('quiz_fields_prefix') || empty(get_option('quiz_fields_prefix')) ){
                //     update_option('quiz_fields_prefix', $quiz_answer_prefixss);
                // }else{
                //     add_option("quiz_fields_prefix", $quiz_answer_prefixss);
                // }



                return wp_send_json(array('success' => 'BB Members Fields Setting Updated!'), 200);

            }else{

                 return wp_send_json(array('error' => 'Bad Request Format!'), 422);   

            }

            // print_r($quiz_field_valuess);
            // print_r($quiz_answer_prefixss);

    wp_die();
}


    public function disable_selected_profile(){

        global $wpdb;
        $bp_fields_table = $wpdb->prefix . 'bp_xprofile_fields';

        $selectedGroups = get_option('quiz_groups_values',true);

        $getXprofileAdditionalFields = $wpdb->get_results("SELECT * FROM ".$bp_fields_table." WHERE `parent_id` = 0 AND `group_id` = $selectedGroups");

        foreach($getXprofileAdditionalFields as $data){
        echo '<input type="hidden" name="disabled_profile" class="disabled_profile'.$data->id.'" value="'.$data->id.'">'; 

        echo '<script type="text/javascript"> var profile_prefix = jQuery(".disabled_profile"+'.$data->id.').val();
            var disable_fields = ".profile.edit #field_"+profile_prefix; jQuery(disable_fields).attr("disabled", "disabled");
        </script>';
    
        }
    }

  
}





?>