<?php 


// Shortcode
function quiz_result_total_shortcode() { 

global $wpdb;
$bp_fields_table = $wpdb->prefix . 'bp_xprofile_fields';
$memberValue = get_option('quiz_bb_mebmer_fields', true);

$quiz_fields_values = get_option('quiz_fields_values', true); 
$adasdcdsc = explode(",", $quiz_fields_values);
$quiz_fields_prefix = get_option('quiz_fields_prefix', true); 
$prefixs = explode(",", $quiz_fields_prefix); 


$selected_profiles = $wpdb->get_results("SELECT name FROM ".$bp_fields_table." WHERE `id` = $memberValue");

$message .= '<ul>';
  
  $message .= '<li>'. $selected_profiles[0]->name .': '. $_GET['Profile'] .'</li>';

foreach( $adasdcdsc as $index => $code ) {
  $message .= '<li>'.$code.': '. $_GET[preg_replace("/\s+/", "", $code)] .'</li>'; 
}
  $message .= '<li>Total: '. $_GET['Total'] .'</li>';
  $message .= '<ul>';

return $message;
}
// register shortcode
add_shortcode('quiz_result', 'quiz_result_total_shortcode');


function current_username() {
  
  $current_user = wp_get_current_user();
  $first_name = get_user_meta( $current_user->ID, 'first_name', true );
  return $first_name; 
}
add_shortcode('username', 'current_username');


add_filter( 'elementor/widget/render_content', 'my_render_heading_shortcode', 10, 2 );
function my_render_heading_shortcode( $content, $widget ) {
    if ( 'heading' === $widget->get_name() ) {
        $content = do_shortcode( $content );
    }
    return $content;
}




function entry_result_data_shortcode( $atts = '' ) { 

  $value = shortcode_atts( array(
        'id' => "",
    ), $atts );

  global $wpdb;
  $gf_entry = $wpdb->prefix . "gf_entry";
  $gquiz_data = $wpdb->prefix . "gquiz_data";
  $bp_fields_table = $wpdb->prefix . 'bp_xprofile_fields';

  $user_id = get_current_user_id();

  $Entry_data = $wpdb->get_results("SELECT * FROM ".$gquiz_data." WHERE `user_id` = ".$user_id." AND `field_id` = ".$value['id']." ");

  $getXprofileAdditionalFields = $wpdb->get_results("SELECT * FROM ".$bp_fields_table." WHERE `parent_id` = ".$value['id']." ");

  $quiz_fields_values = get_option('quiz_fields_values', true); 
  $adasdcdsc = explode(",", $quiz_fields_values);

  $html .= '<table>
              <tr>
                <th>Entry ID</th>
                <th>User ID</th>';
                foreach( $getXprofileAdditionalFields as $code ) { 
                  $html .= '<th>'.$code->name.'</th>';
                }     
   $html .= '<th>Total</th>
              <th>Profile</th>
              <th>Created Date</th>
            </tr>';


  foreach ($Entry_data as $entry) {
    $html .= '<tr>';
    $html .= '<td>'.$entry->entry_id.' </td>';
    $html .= '<td>'.$entry->user_id.' </td>';

    $data = json_decode($entry->quiz_values, TRUE);

    foreach( $getXprofileAdditionalFields as $code ) {

        foreach ($data as $fields) {

           foreach ($fields as $fieldataa) {

                foreach ($fieldataa as $key => $fielsss) {
                  if($code->name == $key){
                     $html .= '<td>'.$fielsss.' </td>';
                  }

                }
           }

        }
      }

    $html .= '<td>'.$data['Total'].' </td>';
    $html .= '<td>'.$data['profile'].' </td>';

    $created_date = $wpdb->get_results("SELECT * FROM ".$gf_entry." WHERE `id` = ".$entry->entry_id."");



    $html .= '<td>'.$created_date[0]->date_created .' </td>';

    $html .= '</tr>';

  }

  $html .= '</table>';

  return $html;


}
add_shortcode('quiz_entry_data', 'entry_result_data_shortcode');




add_action( 'gform_user_registered', 'gform_registration_autologin',  10, 4 );
/**
 * Auto login after registration.
 */
function gform_registration_autologin( $user_id, $user_config, $entry, $password ) {
  $user = get_userdata( $user_id );
  $user_login = $user->user_login;
  $user_password = $password;
       $user->set_role(get_option('default_role', 'subscriber'));

    wp_signon( array(
    'user_login' => $user_login,
    'user_password' =>  $user_password,
    'remember' => false

    ) );
}