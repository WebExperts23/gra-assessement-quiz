<?php

/**
 * Fired during plugin activation
 *
 * @link       https://https://storetransform.com/
 * @since      1.0.0
 *
 * @package    Gravity_Quiz_Assessment
 * @subpackage Gravity_Quiz_Assessment/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Gravity_Quiz_Assessment
 * @subpackage Gravity_Quiz_Assessment/includes
 * @author     Kishan Patel <kishan.storetransform@gmail.com>
 */
class Gravity_Quiz_Assessment_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
