<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://TribePUB.com
 * @since             1.0.0
 * @package           Gravity_Quiz_Assessment
 *
 * @wordpress-plugin
 * Plugin Name:       TribePUB Assessment Tool
 * Plugin URI:        https://TribePUB.com
 * Description:       TribePUB Assessment Tool
 * Version:           1.0.0
 * Author:            TribePUB
 * Author URI:        https://TribePUB.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       gravity-quiz-assessment
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'GRAVITY_QUIZ_ASSESSMENT_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-gravity-quiz-assessment-activator.php
 */
function activate_gravity_quiz_assessment() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-gravity-quiz-assessment-activator.php';
	Gravity_Quiz_Assessment_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-gravity-quiz-assessment-deactivator.php
 */
function deactivate_gravity_quiz_assessment() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-gravity-quiz-assessment-deactivator.php';
	Gravity_Quiz_Assessment_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_gravity_quiz_assessment' );
register_deactivation_hook( __FILE__, 'deactivate_gravity_quiz_assessment' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-gravity-quiz-assessment.php';
require plugin_dir_path( __FILE__ ) . 'admin/partials/gravity-quiz-assessment-shortcode.php';
require plugin_dir_path( __FILE__ ) . 'admin/partials/gravity-quiz-assessment-hooks.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_gravity_quiz_assessment() {

	$plugin = new Gravity_Quiz_Assessment();
	$plugin->run();

}
run_gravity_quiz_assessment();



// When Active Plugin Create Database Hooks
register_activation_hook( __FILE__, 'quizform_data');
function quizform_data() {
  global $wpdb;
  $charset_collate = $wpdb->get_charset_collate();
  $team_table = $wpdb->prefix . 'gquiz_data';
  $sql = "CREATE TABLE `$team_table` (
  `quiz_id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_id` varchar(220) DEFAULT NULL,
  `user_id` varchar(220) DEFAULT NULL,
  `field_id` varchar(220) DEFAULT NULL,
  `quiz_values` text DEFAULT NULL,
  PRIMARY KEY(quiz_id)
  ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
  ";
  if ($wpdb->get_var("SHOW TABLES LIKE '$team_table'") != $team_table) {
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
  }
}


// Plugin deactive remove database 
function quizform_remove_database() {
     global $wpdb;
     $table_name = $wpdb->prefix . 'gquiz_data';
     $sql = "DROP TABLE IF EXISTS $table_name;";
     $wpdb->query($sql);

     delete_option("quizform_db_version");
}    
register_deactivation_hook( __FILE__, 'quizform_remove_database' );


register_activation_hook( __FILE__, 'quizform_prefix');
function quizform_prefix() {
  global $wpdb;
  $charset_collate = $wpdb->get_charset_collate();
  $gquiz_prefix = $wpdb->prefix . 'gquiz_prefix';
  $sql = "CREATE TABLE `$gquiz_prefix` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `prefix_value` varchar(220) DEFAULT NULL,
  `profile_id` int(11) DEFAULT NULL,
  PRIMARY KEY(ID)
  ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
  ";
  if ($wpdb->get_var("SHOW TABLES LIKE '$gquiz_prefix'") != $gquiz_prefix) {
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
  }
}


// function quizprefix_remove_database() {
//      global $wpdb;
//      $gquiz_prefix = $wpdb->prefix . 'gquiz_prefix';
//      $sql = "DROP TABLE IF EXISTS $gquiz_prefix;";
//      $wpdb->query($sql);

//      delete_option("quizprefix_db_version");
// }    
// register_deactivation_hook( __FILE__, 'quizprefix_remove_database' );